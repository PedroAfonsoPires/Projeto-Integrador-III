import ply.yacc as yacc
from analisador_lexico import tokens


def parse_code(data):
    parser = yacc.yacc()
    result = parser.parse(data)
    print("Árvore Sintática:")
    print(result)
    return result


def p_program(p):
    '''program : statement_list'''
    p[0] = p[1]


def p_comment(p):
    '''statement : COMMENT'''
    pass


def p_preprocessor_directive(p):
    '''statement : HASH'''
    pass


def p_statement(p):
    '''statement : declaration
                 | declaration_func
                 | expression_statement'''
    p[0] = p[1]


def p_statement_list(p):
    '''statement_list : statement
                      | statement_list statement'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]


def p_declaration(p):
    '''declaration : TYPE ID SEMICOLON
                   | TYPE ID ASSIGN expression SEMICOLON
                   | TYPE TIMES ID SEMICOLON'''

    if len(p) == 4:  #caso type a;
        p[0] = ('declaration', p[1], p[2])
    elif len(p) == 5:  # caso type *a;
        p[0] = ('declaration', p[1], 'pointer', p[3])
    elif len(p) == 6:  # type a = expression
        p[0] = ('declaration', p[1], p[2], p[4])
    else:
        p[0] = p[1]


def p_expression_statement(p):
    '''expression_statement : expression SEMICOLON'''
    p[0] = ('expr_stmt', p[1])


def p_expression(p):
    '''expression : expression PLUS expression
                  | expression MINUS expression
                  | expression TIMES expression
                  | expression DIVIDE expression
                  | expression MOD expression
                  | NUMBER
                  | ID
                  | TIMES ID
                  | expression ASSIGN expression'''

    if len(p) == 4:
        p[0] = (p[2], p[1], p[3])
    else:
        p[0] = p[1]


def p_parameters(p):
    '''parameters : TYPE ID
                  | TYPE ID COMMA parameters
                  | TYPE TIMES ID
                  | TYPE TIMES ID COMMA parameters'''

    if len(p) == 3:
        p[0] = ('parameter', p[1], p[2])  # Caso para TYPE ID
    elif len(p) == 4:
        p[0] = ('parameter', p[1], f"*{p[2]}")  # Caso para TYPE TIMES ID
    elif len(p) == 6:
        p[0] = ('parameter', p[1], p[2])  # Caso para TYPE ID COMMA parameters
    elif len(p) == 7:
        p[0] = ('parameter', p[1], f"*{p[2]}"
                )  # Caso para TYPE TIMES ID COMMA parameters


def p_declaration_func(p):
    '''declaration_func : TYPE ID LPAREN parameters RPAREN block
                        | TYPE ID LPAREN  RPAREN block'''
    p[0] = ('function_declaration', p[1], p[2], p[4], p[5])


def p_block(p):
    '''block : LBRACE statement_list RBRACE'''
    p[0] = ('block', p[2])


def p_error(p):
    if p:
        print(f"Erro de sintaxe na linha {p.lineno}: {p.value}")
    else:
        print("Erro de sintaxe: final inesperado.")